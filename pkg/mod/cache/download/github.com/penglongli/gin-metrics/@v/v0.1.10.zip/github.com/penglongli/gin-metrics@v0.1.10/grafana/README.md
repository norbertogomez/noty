## Manual 

If you want to use this grafana.json. You should install pie plugin for Grafana:

https://grafana.com/grafana/plugins/grafana-piechart-panel
